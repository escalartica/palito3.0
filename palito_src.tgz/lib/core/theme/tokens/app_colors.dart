import 'package:flutter/material.dart';

/// Fuente única de verdad para la paleta de marca neobrutalista (navy +
/// amarillo + coral). Antes cada pantalla redefinía sus propias constantes
/// locales con los mismos valores hexadecimales — funcionaba porque coincidían,
/// pero un cambio de marca solo en un archivo las habría desincronizado sin
/// que el analizador lo detectase.
///
/// CONTRASTE — los valores marcados con su ratio se han medido contra el
/// fondo con el que se usan, para cumplir WCAG AA (4.5:1 en texto normal).
/// Los grises `Colors.grey.shade400/500` que había repartidos por la app
/// daban entre 1,9:1 y 2,7:1: texto prácticamente ilegible a plena luz.
class AppColors {
  // --- Colores base ---------------------------------------------------
  static const Color primary = Color(0xFFFFD400); // Amarillo de marca
  /// El lienzo de la app. Un solo blanco cálido.
  ///
  /// Había TRES fondos casi iguales conviviendo: `#F4F4F8` (gris frío) como
  /// valor del tema, `#FDFBF7` en Inicio y el formulario, y `#FFFDF5` en
  /// Perfil. Ninguna pantalla usaba el del tema, y el salto de tono entre
  /// Inicio y Perfil se veía al cambiar de pestaña. Ahora es uno.
  static const Color background = Color(0xFFFDFBF7);
  static const Color surface = Colors.white;
  static const Color surfaceWarm = Color(0xFFFFFDF5);
  static const Color textPrimary = Color(0xFF0F172A); // Navy oscuro
  static const Color accent = Color(0xFFFF4D29); // Coral (rellenos, decorativo)

  // --- Texto ----------------------------------------------------------

  /// Texto secundario. Antes era `#7F8C8D` (3,48:1 sobre blanco → no cumple).
  /// 5,94:1 sobre blanco.
  static const Color textSecondary = Color(0xFF5A6572);

  /// Texto terciario / pistas. 4,6:1 sobre blanco. Sustituye a los
  /// `Colors.grey.shade400` (1,9:1) repartidos por Gamer y el detalle.
  static const Color textMuted = Color(0xFF6E7683);

  /// Coral SOLO para texto y bordes de CTA sobre fondo claro: el coral de
  /// marca `#FF4D29` da 3,31:1 sobre blanco y no cumple AA para texto.
  /// 4,70:1 sobre blanco.
  static const Color accentText = Color(0xFFD63A17);

  /// Lo que se escribe encima del amarillo de marca. Material generaba
  /// `onPrimary: white` (1,43:1 sobre #FFD400), ilegible en cualquier
  /// componente que usara los roles del tema en vez de colores a mano.
  static const Color onPrimary = textPrimary;

  /// Lo que se escribe encima del coral.
  ///
  /// Navy, no blanco. Blanco sobre el coral de marca `#FF4D29` mide **3,32:1**
  /// y el mínimo de WCAG AA para texto es 4,5:1 — es decir, el rótulo del
  /// botón principal de "Crear grupo" y "Entrar con un código" no cumplía.
  /// El navy sobre ese mismo coral mide **5,12:1**, y además es lo que hace
  /// la app en todas partes: texto oscuro sobre color, nunca al revés.
  ///
  /// Para ICONOS sobre coral el blanco sí vale (los elementos gráficos solo
  /// necesitan 3:1), y por eso el botón flotante redondo lo conserva.
  static const Color onAccent = textPrimary;

  // --- Estados --------------------------------------------------------
  static const Color error = Color(0xFFC0392B); // 5,4:1 sobre blanco
  static const Color success = Color(0xFF1E7E45); // 5,3:1 sobre blanco
}
