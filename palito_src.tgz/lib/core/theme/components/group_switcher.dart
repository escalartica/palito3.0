import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../providers/auth_provider.dart';
import '../../providers/household_provider.dart';
import '../../services/auth_service.dart';
import '../../utils/app_log.dart';
import '../tokens/app_colors.dart';
import '../tokens/app_shape.dart';
import 'marker_highlight.dart';

/// Selector del grupo activo: qué grupo se está viendo/usando ahora mismo en
/// Inicio/Mapa/Gamer/Perfil. Un toque abre la lista de todos los grupos del
/// usuario (empezando siempre por su diario personal) para cambiar de uno a
/// otro, gestionar sus miembros, o crear/unirse a uno nuevo.
/// Cabecera de Inicio: DE QUÉ DIARIO estás viendo el contenido, y el control
/// para cambiarlo.
///
/// La versión anterior era una pastilla de unos 30 píxeles de alto, debajo de
/// un titular enorme que ponía "Palito de Sabores". Es decir: el elemento más
/// grande de la pantalla repetía el nombre de la app —que el usuario ya sabe,
/// y que además está en el logotipo de al lado— mientras que el dato que de
/// verdad cambia lo que estás viendo iba en letra pequeña y con aspecto de
/// etiqueta, no de botón. Ese es el origen directo de "no entiendo los
/// grupos": la app nunca decía, con todas sus letras y en el sitio donde se
/// mira primero, en qué diario estás ni que puedes cambiarlo.
///
/// Ahora el nombre del diario ES el titular, con su galón y su flecha, y
/// debajo dice quién lo ve.
class GroupSwitcher extends ConsumerWidget {
  const GroupSwitcher({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AsyncValue<Map<String, dynamic>?> activeGroupAsync = ref.watch(
      activeGroupDocProvider,
    );
    final String? activeGroupId = ref.watch(activeGroupIdProvider);
    final String? personalGroupId = ref.watch(personalGroupIdProvider);
    final List<String> members = ref.watch(activeGroupMembersProvider);
    final int groupCount = ref.watch(userGroupIdsProvider).length;

    final bool isPersonal =
        activeGroupId != null && activeGroupId == personalGroupId;

    // Antes, un error del stream se mostraba como "Cargando…" para siempre.
    final String label;
    if (activeGroupAsync.hasError) {
      label = 'Sin grupo';
    } else if (activeGroupAsync.isLoading && !activeGroupAsync.hasValue) {
      label = 'Cargando…';
    } else if (isPersonal) {
      label = 'Mi diario';
    } else {
      label = (activeGroupAsync.valueOrNull?['name'] as String?) ?? 'Grupo';
    }

    final String subtitle;
    if (activeGroupAsync.hasError) {
      subtitle = 'No se pudo cargar';
    } else if (isPersonal) {
      subtitle = 'Privado — solo tú';
    } else if (members.length <= 1) {
      subtitle = 'Solo tú de momento';
    } else {
      subtitle = 'Tú y ${members.length - 1} '
          '${members.length - 1 == 1 ? 'persona' : 'personas'}';
    }

    return Semantics(
      button: true,
      label: 'Estás viendo el diario $label. $subtitle. '
          'Toca para cambiar de diario',
      child: InkWell(
        borderRadius: BorderRadius.circular(AppRadius.md),
        onTap: () => openGroupSwitcher(context, ref),
        child: ExcludeSemantics(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Text(
                  'ESTÁS VIENDO',
                  style: GoogleFonts.inter(
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.0,
                    color: AppColors.textSecondary,
                  ),
                ),
                const SizedBox(height: 2),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Flexible(
                      // El rotulador va AQUÍ y en ningún otro sitio de la
                      // app. Señalar a mano funciona porque dice "esto de
                      // aquí": con un solo trazo, el nombre del diario es lo
                      // primero que ve el ojo al abrir. Con tres trazos por
                      // pantalla no diría nada.
                      //
                      // Navy sobre el amarillo de marca mide 12,47:1 — el
                      // contraste más alto de toda la app.
                      child: MarkerHighlight(
                        child: Text(
                          label,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: GoogleFonts.outfit(
                            fontSize: 26,
                            fontWeight: FontWeight.w900,
                            letterSpacing: -0.6,
                            height: 1.1,
                            color: AppColors.textPrimary,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                    // El galón amarillo con la flecha: sin él, un titular
                    // grande no se lee como algo pulsable.
                    Container(
                      width: 26,
                      height: 26,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: AppColors.primary,
                        borderRadius: BorderRadius.circular(AppRadius.xs),
                        border: Border.all(
                          color: AppColors.textPrimary,
                          width: AppBorder.normal,
                        ),
                        boxShadow: const <BoxShadow>[
                          BoxShadow(
                            color: AppColors.textPrimary,
                            offset: Offset(2, 2),
                            blurRadius: 0,
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.unfold_more_rounded,
                        size: 16,
                        color: AppColors.textPrimary,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 3),
                Text(
                  // La hoja ya no solo cambia de diario: también es donde
                  // se ve quién está en cada uno, se invita, se entra con un
                  // código y se crea uno nuevo. Con un solo diario todavía
                  // no hay nada que "cambiar", pero sí hay dónde compartir.
                  groupCount > 1
                      ? '$subtitle · Diarios y gente'
                      : '$subtitle · Compartir con alguien',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.inter(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Abre la lista de grupos. Expuesto como función para que Perfil pueda usar
/// exactamente el mismo panel (antes solo se llegaba a él desde un chip
/// pequeño en Inicio, cuatro niveles por debajo de donde el usuario lo busca).
Future<void> openGroupSwitcher(BuildContext context, WidgetRef ref) async {
  HapticFeedback.selectionClick();

  final List<String> groupIds = ref.read(userGroupIdsProvider);
  final String? personalGroupId = ref.read(personalGroupIdProvider);
  final String? activeGroupId = ref.read(activeGroupIdProvider);
  final String? myUid = ref.read(currentUidProvider);

  // Los datos se cargan bajo demanda, solo al abrir el selector.
  //
  // Cada lectura va en su propio try/catch: si te han expulsado de un grupo,
  // su `get()` devuelve `permission-denied`, y antes ese fallo se propagaba
  // por el `Future.wait` y el panel NO SE ABRÍA NUNCA MÁS. La autolimpieza
  // que se supone que cubre ese caso era código inalcanzable, porque la
  // excepción saltaba antes de llegar a ella.
  final List<DocumentSnapshot<Map<String, dynamic>>> valid =
      <DocumentSnapshot<Map<String, dynamic>>>[];
  final List<String> toForget = <String>[];

  await Future.wait(
    groupIds.map((String id) async {
      try {
        final DocumentSnapshot<Map<String, dynamic>> snap =
            await FirebaseFirestore.instance.collection('groups').doc(id).get();

        final List<String> members =
            (snap.data()?['members'] as List<dynamic>?)
                ?.whereType<String>()
                .toList() ??
            const <String>[];

        // Un documento que ya no existe también hay que olvidarlo: antes
        // pasaba el filtro y se pintaba como un grupo llamado "Grupo" con
        // botones de invitar que fallaban al pulsarlos.
        if (!snap.exists || (myUid != null && !members.contains(myUid))) {
          toForget.add(id);
          return;
        }

        valid.add(snap);
      } on FirebaseException catch (e) {
        if (e.code == 'permission-denied' || e.code == 'not-found') {
          toForget.add(id);
        } else {
          AppLog.w('No se pudo leer un grupo: ${e.code}');
        }
      }
    }),
  );

  if (myUid != null && toForget.isNotEmpty) {
    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(myUid)
          .set(<String, dynamic>{
            'groupIds': FieldValue.arrayRemove(toForget),
            'updatedAt': FieldValue.serverTimestamp(),
          }, SetOptions(merge: true));
    } catch (_) {
      AppLog.w('No se pudo limpiar la lista de grupos.');
    }

    if (toForget.contains(ref.read(activeGroupIdOverrideProvider))) {
      ref.read(activeGroupIdOverrideProvider.notifier).state = null;
    }
  }

  if (!context.mounted) return;

  await showModalBottomSheet<void>(
    context: context,
    // El shell pinta el dock por encima del contenido dentro de su propio
    // Stack (ver main.dart); un sheet en el Navigator anidado quedaría por
    // debajo. El Navigator raíz lo pinta por encima de todo.
    useRootNavigator: true,
    backgroundColor: AppColors.surface,
    showDragHandle: true,
    // DESPLAZABLE Y ACOTADO. La lista no cabía: con cinco diarios el panel se
    // desbordaba por abajo —la cinta amarilla y negra de Flutter— y las
    // acciones del final quedaban fuera de la pantalla, sin forma de llegar a
    // ellas porque la columna no se podía desplazar. El número de grupos de
    // un usuario no tiene techo, así que la altura tampoco puede darse por
    // supuesta.
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (BuildContext sheetContext) {
      return SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(
            maxHeight: MediaQuery.sizeOf(sheetContext).height * 0.8,
          ),
          child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                // "Diarios" en todas partes. La app los llamaba "grupos"
                // aquí y "diarios" en el resto de pantallas: dos palabras
                // para la misma cosa obligan a deducir que son la misma.
                'Tus diarios',
                style: GoogleFonts.outfit(
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  color: AppColors.textPrimary,
                ),
              ),
              const SizedBox(height: 12),
              for (final DocumentSnapshot<Map<String, dynamic>> snap in valid)
                _GroupTile(
                  name: snap.id == personalGroupId
                      ? 'Mi diario'
                      : (snap.data()?['name'] as String?) ?? 'Grupo',
                  memberCount:
                      (snap.data()?['members'] as List<dynamic>?)?.length ?? 1,
                  isPersonal:
                      snap.id == personalGroupId ||
                      snap.data()?['isPersonal'] == true,
                  isActive: snap.id == activeGroupId,
                  onTap: () {
                    ref.read(activeGroupIdOverrideProvider.notifier).state =
                        snap.id;
                    Navigator.pop(sheetContext);
                  },
                  onManage: () {
                    Navigator.pop(sheetContext);
                    openGroupMembersSheet(
                      context,
                      ref,
                      groupId: snap.id,
                      groupData: snap.data() ?? const <String, dynamic>{},
                    );
                  },
                ),
              const Divider(height: 28),
              // Dos filas, no una. "Compartir con alguien más" mezclaba tres
              // acciones distintas —invitar a tu grupo, entrar en el de otro
              // y crear uno nuevo— bajo una etiqueta que no es ninguna de las
              // tres. Quien había recibido un código no se le ocurría que
              // "compartir" fuera el sitio donde meterlo.
              _GroupTile(
                icon: Icons.login_rounded,
                name: 'Entrar con un código',
                isActive: false,
                isPersonal: true,
                memberCount: 0,
                onTap: () {
                  Navigator.pop(sheetContext);
                  context.push('/household-setup?mode=join');
                },
              ),
              _GroupTile(
                icon: Icons.group_add_rounded,
                name: 'Crear un diario compartido',
                isActive: false,
                isPersonal: true,
                memberCount: 0,
                onTap: () {
                  Navigator.pop(sheetContext);
                  context.push('/household-setup');
                },
              ),
            ],
          ),
          ),
        ),
      );
    },
  );
}

/// Panel de miembros de un grupo, con salir/expulsar.
Future<void> openGroupMembersSheet(
  BuildContext context,
  WidgetRef ref, {
  required String groupId,
  required Map<String, dynamic> groupData,
}) async {
  await showModalBottomSheet<void>(
    context: context,
    useRootNavigator: true,
    backgroundColor: AppColors.surface,
    showDragHandle: true,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (BuildContext sheetContext) => _MembersSheet(
      groupId: groupId,
      groupName: (groupData['name'] as String?) ?? 'Grupo',
      isPersonal: groupData['isPersonal'] == true,
      createdBy: groupData['createdBy'] as String?,
      initialMembers:
          (groupData['members'] as List<dynamic>?)
              ?.whereType<String>()
              .toList() ??
          const <String>[],
      memberProfiles:
          (groupData['memberProfiles'] as Map<dynamic, dynamic>?)
              ?.cast<String, dynamic>() ??
          const <String, dynamic>{},
    ),
  );
}

/// Lista de miembros de un grupo con acciones de salir/expulsar. Es
/// `Stateful` para poder quitar una fila al instante tras expulsar a alguien,
/// sin esperar a que el stream del grupo se vuelva a leer.
class _MembersSheet extends ConsumerStatefulWidget {
  const _MembersSheet({
    required this.groupId,
    required this.groupName,
    required this.isPersonal,
    required this.createdBy,
    required this.initialMembers,
    required this.memberProfiles,
  });

  final String groupId;
  final String groupName;
  final bool isPersonal;
  final String? createdBy;
  final List<String> initialMembers;
  final Map<String, dynamic> memberProfiles;

  @override
  ConsumerState<_MembersSheet> createState() => _MembersSheetState();
}

class _MembersSheetState extends ConsumerState<_MembersSheet> {
  final List<String> _members = <String>[];
  String? _busyUid;

  @override
  void initState() {
    super.initState();
    _members.addAll(widget.initialMembers);
  }

  String _nameFor(String uid) {
    final Map<String, dynamic>? profile =
        widget.memberProfiles[uid] as Map<String, dynamic>?;
    final String? name = (profile?['displayName'] as String?)?.trim();
    return name?.isNotEmpty == true ? name! : AuthService.unnamedMember;
  }

  Future<void> _confirmAndRun({
    required String title,
    required String content,
    required String confirmLabel,
    required Future<void> Function() action,
    required String uid,
    required bool isLeaving,
  }) async {
    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) => AlertDialog(
        title: Text(title),
        content: Text(content),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: Text(
              confirmLabel,
              style: GoogleFonts.inter(
                color: AppColors.error,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    setState(() => _busyUid = uid);

    try {
      await action();

      if (!mounted) return;

      setState(() => _members.remove(uid));

      // Al salir del grupo que estabas viendo, nadie reseteaba el override:
      // todos los streams (recuerdos, mapa, gamer) pasaban a
      // `permission-denied` y la app se quedaba en blanco cargando para
      // siempre.
      if (isLeaving && ref.read(activeGroupIdProvider) == widget.groupId) {
        ref.read(activeGroupIdOverrideProvider.notifier).state = null;
      }

      if (isLeaving && mounted) Navigator.of(context).pop();
    } on FirebaseException catch (e) {
      if (!mounted) return;
      AppLog.w('Acción sobre miembros fallida: ${e.code}');
      _showError(
        e.code == 'permission-denied'
            ? 'No tienes permiso para hacer eso en este grupo.'
            : 'No se pudo completar la acción. Comprueba tu conexión.',
      );
    } catch (e, st) {
      if (!mounted) return;
      AppLog.e('Acción sobre miembros fallida', e, st);
      _showError('No se pudo completar la acción. Inténtalo de nuevo.');
    } finally {
      if (mounted) setState(() => _busyUid = null);
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(content: Text(message), behavior: SnackBarBehavior.floating),
      );
  }

  @override
  Widget build(BuildContext context) {
    final String? myUid = ref.watch(currentUidProvider);

    // Quien creó el grupo puede expulsar. Si el creador ya no es miembro
    // (se fue), el grupo quedaba ingobernable: nadie volvía a ver el botón
    // de expulsar nunca más. Ahora, en ese caso, puede cualquier miembro —
    // y `firestore.rules` aplica exactamente el mismo criterio, así que no
    // es solo cosmético como antes.
    final bool creatorPresent =
        widget.createdBy != null && _members.contains(widget.createdBy);
    final bool canModerate =
        myUid != null && (myUid == widget.createdBy || !creatorPresent);

    final householdService = ref.read(householdServiceProvider);

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              widget.isPersonal
                  ? 'Mi diario'
                  : 'Miembros de «${widget.groupName}»',
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: GoogleFonts.outfit(
                fontSize: 18,
                fontWeight: FontWeight.w900,
                color: AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              widget.isPersonal
                  ? 'Tu diario personal es solo tuyo: no se puede compartir '
                        'ni invitar a nadie.'
                  : canModerate
                  ? 'Puedes invitar a más gente o quitar a quien ya no '
                        'deba estar.'
                  : 'Solo quien creó el grupo puede quitar a otras '
                        'personas.',
              style: GoogleFonts.inter(
                fontSize: 13,
                height: 1.4,
                color: AppColors.textSecondary,
              ),
            ),
            const SizedBox(height: 16),
            if (_members.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 20),
                child: Text(
                  'No se ha podido cargar la lista de miembros.',
                  style: GoogleFonts.inter(
                    fontSize: 14,
                    color: AppColors.textSecondary,
                  ),
                ),
              )
            else
              Flexible(
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: _members.length,
                  itemBuilder: (BuildContext context, int index) {
                    final String uid = _members[index];
                    final String name = _nameFor(uid);
                    final bool isMe = uid == myUid;

                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Row(
                        children: <Widget>[
                          const Icon(
                            Icons.person_rounded,
                            size: 20,
                            color: AppColors.textSecondary,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  isMe ? '$name (tú)' : name,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: GoogleFonts.inter(
                                    fontSize: 15,
                                    fontWeight: FontWeight.w600,
                                    color: AppColors.textPrimary,
                                  ),
                                ),
                                if (uid == widget.createdBy)
                                  Text(
                                    'Creó el grupo',
                                    style: GoogleFonts.inter(
                                      fontSize: 11,
                                      color: AppColors.textSecondary,
                                    ),
                                  ),
                              ],
                            ),
                          ),
                          if (_busyUid == uid)
                            const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          else if (isMe && !widget.isPersonal)
                            TextButton(
                              style: TextButton.styleFrom(
                                minimumSize: const Size(0, 48),
                              ),
                              onPressed: () => _confirmAndRun(
                                uid: uid,
                                isLeaving: true,
                                title: 'Salir del grupo',
                                content:
                                    'Dejarás de ver y compartir contenido con '
                                    '«${widget.groupName}». Podrás volver a '
                                    'unirte si alguien te invita de nuevo.',
                                confirmLabel: 'Salir',
                                action: () => householdService.leaveGroup(
                                  groupId: widget.groupId,
                                  uid: uid,
                                ),
                              ),
                              child: const Text('Salir'),
                            )
                          else if (!isMe && canModerate)
                            TextButton(
                              style: TextButton.styleFrom(
                                foregroundColor: AppColors.error,
                                minimumSize: const Size(0, 48),
                              ),
                              onPressed: () => _confirmAndRun(
                                uid: uid,
                                isLeaving: false,
                                title: 'Quitar a $name',
                                content:
                                    '$name dejará de tener acceso a '
                                    '«${widget.groupName}» y a su contenido '
                                    'compartido.',
                                confirmLabel: 'Quitar',
                                action: () => householdService.removeMember(
                                  groupId: widget.groupId,
                                  targetUid: uid,
                                ),
                              ),
                              child: const Text('Quitar'),
                            ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            if (!widget.isPersonal) ...<Widget>[
              const Divider(height: 24),
              TextButton.icon(
                style: TextButton.styleFrom(
                  minimumSize: const Size(0, 48),
                  foregroundColor: AppColors.textPrimary,
                ),
                onPressed: () {
                  Navigator.of(context).pop();
                  context.push('/invite-partner', extra: widget.groupId);
                },
                icon: const Icon(Icons.person_add_alt_1_rounded, size: 18),
                label: const Text('Invitar a alguien con un código'),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _GroupTile extends StatelessWidget {
  const _GroupTile({
    required this.name,
    required this.isActive,
    required this.isPersonal,
    required this.memberCount,
    required this.onTap,
    this.icon,
    this.onManage,
  });

  final String name;
  final bool isActive;
  final bool isPersonal;
  final int memberCount;
  final VoidCallback onTap;
  final IconData? icon;
  final VoidCallback? onManage;

  @override
  Widget build(BuildContext context) {

    return InkWell(
      borderRadius: BorderRadius.circular(AppRadius.md),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 4),
        child: Row(
          children: <Widget>[
            Icon(
              icon ??
                  (isActive
                      ? Icons.radio_button_checked_rounded
                      : Icons.radio_button_unchecked_rounded),
              size: 20,
              color: isActive ? AppColors.textPrimary : AppColors.textSecondary,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.inter(
                      fontSize: 15,
                      fontWeight: isActive ? FontWeight.w700 : FontWeight.w500,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  if (memberCount > 0)
                    Text(
                      isPersonal
                          ? 'Privado'
                          : '$memberCount ${memberCount == 1 ? 'persona' : 'personas'}',
                      style: GoogleFonts.inter(
                        fontSize: 11,
                        color: AppColors.textSecondary,
                      ),
                    ),
                ],
              ),
            ),
            // Un botón con su nombre escrito, no un menú de tres puntos.
            //
            // El "..." era exactamente lo que la gente no encontraba: para
            // ver quién está en un diario —o para quitar a alguien— había
            // que adivinar que se escondía ahí dentro. Un icono de tres
            // puntos no promete nada, así que nadie lo pulsa.
            //
            // Invitar ya no vive aquí: vive DENTRO de la hoja de personas,
            // que es donde tiene sentido. Primero ves quién hay, luego
            // añades. Antes eran dos caminos distintos para la misma tarea.
            if (onManage != null)
              Semantics(
                button: true,
                label: 'Personas de $name',
                child: InkWell(
                  borderRadius: BorderRadius.circular(AppRadius.sm),
                  onTap: onManage,
                  child: Container(
                    // 44x44 reales, el mínimo táctil de iOS.
                    constraints: const BoxConstraints(
                      minWidth: 44,
                      minHeight: 44,
                    ),
                    alignment: Alignment.center,
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: ExcludeSemantics(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          const Icon(
                            Icons.group_rounded,
                            size: 18,
                            color: AppColors.textPrimary,
                          ),
                          const SizedBox(height: 2),
                          Text(
                            'Personas',
                            style: GoogleFonts.inter(
                              fontSize: 10,
                              fontWeight: FontWeight.w800,
                              color: AppColors.textSecondary,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
