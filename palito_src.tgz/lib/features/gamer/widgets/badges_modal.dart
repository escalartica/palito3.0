import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'badge_pill.dart';
import '../../../core/theme/tokens/app_colors.dart';
import '../../../core/theme/tokens/app_shape.dart';

const _kDark = AppColors.textPrimary;
const _kYellow = AppColors.primary;
const _kRed = AppColors.accent;

/// Naranja de insignias/historial. Debe coincidir con `_kBadgeOrange` de
/// gamer_page.dart — ver ese comentario para el porqué de mantenerlo local
/// en vez de en AppColors.
const _kBadgeOrange = Color(0xFFFF9F1C);

/// Modal con el ranking de comensales (puntos y medallas) y los logros
/// especiales globales de la sesión. Extraído de gamer_page.dart.
///
/// [players] debe llegar ya ordenado por puntuación (mayor a menor); el
/// orden se calcula en el llamador para no duplicar esa lógica aquí.
class BadgesModal extends StatelessWidget {
  const BadgesModal({
    super.key,
    required this.players,
    required this.achievements,
  });

  final List<Map<String, dynamic>> players;
  final List<Map<String, dynamic>> achievements;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(24),
    constraints: BoxConstraints(
      maxHeight: MediaQuery.of(context).size.height * 0.9,
    ),
    decoration: const BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
    ),
    child: SingleChildScrollView(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Row(
                  children: [
                    const Icon(
                      Icons.military_tech_rounded,
                      color: _kBadgeOrange,
                      size: 28,
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'Insignias y Logros de la Mesa',
                        style: GoogleFonts.outfit(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: _kDark,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              IconButton(
                icon: const Icon(Icons.close_rounded),
                tooltip: 'Cerrar',
                onPressed: () => Navigator.pop(context),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            'Ranking ordenado por puntuación, medallas e insignias desbloqueadas.',
            style: GoogleFonts.inter(fontSize: 13, color: AppColors.textSecondary),
          ),
          const SizedBox(height: 16),
          ...players.map((player) {
            final playerColor = player['color'] as Color;
            return Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.surfaceWarm,
                borderRadius: BorderRadius.circular(AppRadius.md),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 18,
                          backgroundColor: playerColor.withValues(alpha: 0.2),
                          child: Icon(
                            player['icon'] as IconData,
                            color: playerColor,
                            size: 18,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            player['name'] as String,
                            style: GoogleFonts.outfit(
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                              color: _kDark,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      BadgePill(
                        text: '🏆 ${player['medals']} medallas',
                        bgColor: _kYellow.withValues(alpha: 0.25),
                      ),
                      const SizedBox(height: 6),
                      BadgePill(
                        text: '⭐ ${player['points']} pts',
                        bgColor: _kRed.withValues(alpha: 0.15),
                        textColor: _kRed,
                      ),
                    ],
                  ),
                ],
              ),
            );
          }),
          const SizedBox(height: 16),
          Text(
            'Logros Especiales Globales',
            style: GoogleFonts.outfit(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: _kDark,
            ),
          ),
          const SizedBox(height: 10),
          ...achievements.map((a) {
            final unlocked = a['unlocked'] == true;
            final color = a['color'] as Color;
            return Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: unlocked ? color.withValues(alpha: 0.08) : AppColors.surface,
                borderRadius: BorderRadius.circular(AppRadius.md),
                border: Border.all(
                  color: unlocked
                      ? color.withValues(alpha: 0.3)
                      : AppColors.textMuted,
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    a['icon'] as IconData,
                    color: unlocked ? color : AppColors.textMuted,
                    size: 28,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          a['title'] as String,
                          style: GoogleFonts.outfit(
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                            color: unlocked ? _kDark : AppColors.textSecondary,
                          ),
                        ),
                        Text(
                          a['desc'] as String,
                          style: GoogleFonts.inter(
                            fontSize: 12,
                            color: AppColors.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Icon(
                    unlocked ? Icons.check_circle_rounded : Icons.lock_rounded,
                    color: unlocked ? color : AppColors.textMuted,
                    size: 20,
                  ),
                ],
              ),
            );
          }),
          const SizedBox(height: 16),
        ],
      ),
    ),
  );
}
